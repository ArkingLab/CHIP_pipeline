#!/bin/bash

#echo $1 > PathToFOI.tmp;
#cat $1|awk '/CHROM/{print NR}' > LOC.txt;
cat mutect2.filter.1.vcf| grep multiallelic > CheckMultiallelicNODEL.txt;
./Manual_ConversionToAnnovar_UKB.R;

./table_annovar.pl fin_df_Genome.input.txt humandb/ -buildver hg38 -out Out -remove -protocol refGene,gnomad211_exome -operation g,f -nastring . -csvout -polish

./Manual_UKB_WhiteList.R;

rm Out.hg38_multianno.csv;
#rm PathToFOI.tmp;
#rm LOC.txt;
rm fin_df_Genome.input.txt;

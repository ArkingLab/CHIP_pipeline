#!/usr/local/bin/Rscript
library(dplyr, quietly = TRUE)
library(stringr, quietly = TRUE)
rm(list=ls())

fin_df <- read.delim("mutect2.filter.1.vcf", skip = 3434)

fin_df$REF <- ifelse(fin_df$REF == "TRUE", "T", fin_df$REF)
fin_df$ALT <- ifelse(fin_df$ALT == "TRUE", "T", fin_df$ALT)

fin_df$End <- fin_df$POS+(nchar(fin_df$REF)-1)

fin_df$X.CHROM <- str_remove(fin_df$X.CHROM, "chr")

fin_df <- fin_df%>%
  select(X.CHROM, POS, End, REF, ALT)%>%
  distinct(X.CHROM, POS, End, REF, ALT)

write.table(fin_df, file = "fin_df_Genome.input.txt", quote = FALSE, row.names = FALSE,
            col.names = FALSE, sep = "\t")
















